package com.example.fb02;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {
Context context=this;
FirebaseFirestore database;
TextView tvResult;
Button btn,btn_ud,btn_del;
String id="";
Todo todo=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn=findViewById(R.id.btn);
        tvResult=findViewById(R.id.txt);
        database=FirebaseFirestore.getInstance();//tao doi tuong data
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InsertDatabase();
            }
        });

    btn_ud=findViewById(R.id.btn_ud);
        btn_ud.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UpdateDatabase();
            }
        });


        btn_del=findViewById(R.id.btn_del);
        btn_del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeleteDatabase();
            }
        });

SelectData(tvResult);

    }
    public void InsertDatabase(){
        id= UUID.randomUUID().toString();//lay 1 id ngau nhien
        todo=new Todo(id,"title2","content2");
        //chuyen doi sang hasmap
        HashMap<String,Object> mapTodo=todo.convertHasMap();
        //thuc hien insert
        database.collection("TODO")
                .document(id)//lay ten dong
                .set(mapTodo)//thuc hien insert
        //inseert thanh cong
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        tvResult.setText("Insert thanh cong");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tvResult.setText(e.getMessage());
                    }
                });
    }

    public void UpdateDatabase(){
        id="42864640-e943-4375-8e62-d8c30410db94";//lat nua can copy id da insert vao day
        todo=new Todo(id,"title da update lan 1","content da update lan 1");
        //thuc hien update
        database.collection("TODO")// lay ten bang du lieu
                .document(todo.getId())//lay du lieu can update
                .update(todo.convertHasMap())//update doi tuong
                //thanh cong
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        tvResult.setText("Update thanh cong");
                    }
                })
                //that bai
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tvResult.setText(e.getMessage());
                    }
                });
    }

    public void DeleteDatabase(){
        id="24c2358b-8348-4e13-9251-7699b82a0c89";//lat nua can copy id vao day
        //thuc hien xoa
        database.collection("TODO")//lay ten bang du lieu
                .document(id)//lay ten dong du lieu
                .delete()//thuc hien xoa
        //thanh cong
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        tvResult.setText("Delet thanh cong");
                    }
                })
                //that bai
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tvResult.setText(e.getMessage());
                    }
                });
    }
    String strKQ="";
    public ArrayList<Todo> SelectData(TextView tvResult){
        ArrayList<Todo> list = new ArrayList<>();
        database.collection("TODO")
                .get()//lay toan bo du lieu
                //thanh cong
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()){
                            strKQ="";
                            for(QueryDocumentSnapshot d : task.getResult()){
                                Todo todo1 = d.toObject(Todo.class);//chuyen doi tuong sang todo
                                strKQ += "ID"+ todo1.getId()+ "\n";
                                list.add(todo1);
                            }
                            tvResult.setText(strKQ);//dua du lieu len text
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tvResult.setText(e.getMessage());
                    }
                });
        return list;
    }
}